

    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/css/theme.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/bootstrap.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/css/vendors.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/css/daterangepicker.min.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/theme.min.css') }}" />


      <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/css/tagify.min.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/css/tagify-data.min.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/css/quill.min.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/css/select2.min.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/css/select2-theme.min.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/css/datepicker.min.css')}}">


    @stack('styles')
